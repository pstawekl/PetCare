public class DogBreed
{
    public string Name { get; set; }
    public string BreedGroup { get; set; }
    public string Temperament { get; set; }
    public string Origin { get; set; }
}